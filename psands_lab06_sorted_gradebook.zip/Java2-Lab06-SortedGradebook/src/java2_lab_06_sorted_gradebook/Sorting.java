/******************************************************************************
*
* Sorting.java
*
* Created by: Parker
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Contains a modified selection sort algorithm for sorting an array 
*    of Student objects.
* 2. Uses the Student class’s compareTo() method to establish the sorting order.
* 3. Since compareTo() is designed for descending order by test score, the
*    "minimum" element in each iteration is the Student with the highest score.
* 4. Performs sorting in place on the provided Student array.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Create a Sorting class that includes a public static method called 
*    selectionSort().
* 2. The selectionSort() method should accept an array of Student objects.
* 3. Use a nested loop to traverse the array and determine the index of the 
*    Student that should appear first based on compareTo().
* 4. Swap elements as needed to position the highest score at the beginning 
*    of the array progressing to the lowest.
*
******************************************************************************
*
* LAB HINTS
* 1. The selection sort algorithm repeatedly finds the "smallest" element
*    (per the compareTo() method) and swaps it to its correct position.
* 2. In this case, "smallest" means the Student with the highest test score.
* 3. Use a temporary variable to facilitate swapping of Student objects.
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Determine the length of the Student array.
* 2. Loop from index 0 to n-2:
*      a. Assume the current index (i) holds the "minimum" element.
*      b. Use an inner loop (from i+1 to n-1) to search for an element that is 
*         "smaller" (i.e., has a higher score based on compareTo()).
*      c. If found, update the index of the minimum element.
*      d. After the inner loop, swap the Student at index i with the Student at 
*         the identified minimum index.
* 3. Continue until the entire array is sorted in descending order by test score.
*
******************************************************************************
*
* INPUT
* 1. An array of Student objects (Student[])
*
* PROCESSING AND CALCULATIONS
* 1. Iterate through the array comparing elements using compareTo().
* 2. Swap elements based on the results to order the array correctly.
*
* OUTPUT
* 1. The original array rearranged in descending order by test score.
*
******************************************************************************
*
* PSEUDOCODE - Sorting Class
*
* CLASS Sorting
*
* METHOD: selectionSort(students: Student[])
*   SET n = length of students array
*   FOR i FROM 0 to n - 2 DO:
*       SET minIndex = i
*       FOR j FROM i + 1 to n - 1 DO:
*           IF students[j].compareTo(students[minIndex]) < 0 THEN:
*               SET minIndex = j
*       END FOR
*       // Swap students[i] with students[minIndex]
*       SET temp = students[i]
*       SET students[i] = students[minIndex]
*       SET students[minIndex] = temp
*   END FOR
*
******************************************************************************/
package java2_lab_06_sorted_gradebook;

public class Sorting {

    /**
     * Sorts an array of Student objects in descending order by test score.
     * Uses the selection sort algorithm.
     *
     * @param students an array of Student objects to be sorted
     */
    public static void selectionSort(Student[] students) {
        int n = students.length;
        // Loop through the array (except for the last element)
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;  // Here, 'minIndex' holds the index of the student with the highest score (lowest compareTo value) in this context.
            // Inner loop to find the student with the "minimum" (highest score) according to compareTo
            for (int j = i + 1; j < n; j++) {
                if (students[j].compareTo(students[minIndex]) < 0) {
                    minIndex = j;
                }
            }
            // Swap the student at index i with the student at minIndex
            Student temp = students[i];
            students[i] = students[minIndex];
            students[minIndex] = temp;
        }
    }
}
