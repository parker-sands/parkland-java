/******************************************************************************
*
* Student.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Encapsulates a student's data including first name, last name, and test score.
* 2. Implements the Comparable<Student> interface to allow sorting by test score.
* 3. Compares students in descending order by score, with tie-breakers using last name
*    and first name.
* 4. Provides formatted output of student details via the toString() method.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Create a Student class that implements Comparable<Student>.
* 2. Store the following data:
*    - A String to store the student's first name.
*    - A String to store the student's last name.
*    - An int to store the student's test score (0–100).
* 3. Provide the following methods:
*    - A constructor to initialize the first name, last name, and test score.
*    - Getters for each instance variable: getFirstName(), getLastName(), and getScore().
*    - A compareTo() method to compare Student objects for sorting (descendant order by score).
*    - A toString() method to return a formatted string representation of the Student.
*
******************************************************************************
*
* LAB HINTS
* 1. Use "implements Comparable<Student>" in the class header.
* 2. In compareTo(), return -1 if this student has a higher score than the other,
*    1 if lower, and if scores are equal, then compare last names and first names.
* 3. Ensure the toString() method neatly formats the student's details.
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Define the instance variables: firstName, lastName, and score.
* 2. Create a constructor to initialize these variables.
* 3. Write accessor methods to retrieve the values.
* 4. In compareTo(), use descending order: higher test scores should sort before lower.
*    - Use secondary comparison (last name then first name) if scores are equal.
* 5. Implement toString() to produce a string like: "FirstName LastName Score".
*
******************************************************************************
*
* INPUT
* 1. firstName (String)
* 2. lastName  (String)
* 3. score     (int; must be between 0 and 100)
*
* PROCESSING AND CALCULATIONS
* 1. Store and retrieve student data.
* 2. Compare student scores for sorting, using lexicographic comparisons for names
*    in the event of equal scores.
*
* OUTPUT
* 1. A formatted string representing the student's full details.
*
******************************************************************************
*
* PSEUDOCODE - Student Class
*
* CLASS Student IMPLEMENTS Comparable<Student>
*
* VARIABLES:
*   firstName : String    // Student's first name
*   lastName  : String    // Student's last name
*   score     : int       // Student's test score (0–100)
*
* CONSTRUCTOR: Student(firstName: String, lastName: String, score: int)
*   SET this.firstName = firstName
*   SET this.lastName = lastName
*   SET this.score = score
*
* METHOD: getFirstName() -> String
*   RETURN firstName
*
* METHOD: getLastName() -> String
*   RETURN lastName
*
* METHOD: getScore() -> int
*   RETURN score
*
* METHOD: compareTo(other: Student) -> int
*   // Compare by test score in descending order.
*   IF this.score > other.score THEN
*       RETURN -1   // This student comes before the other.
*   ELSE IF this.score < other.score THEN
*       RETURN 1    // This student comes after the other.
*   ELSE
*       // If test scores are equal, compare by last name (ignoring case).
*       SET lastCompare = compare this.lastName with other.lastName (ignore case)
*       IF lastCompare != 0 THEN
*           RETURN lastCompare
*       ELSE
*           // If last names are equal, compare by first name (ignoring case).
*           RETURN compare this.firstName with other.firstName (ignore case)
*   END IF
*
* METHOD: toString() -> String
*   // Format the student information for display.
*   RETURN firstName + " " + lastName + " " + score
*
******************************************************************************/
package java2_lab_06_sorted_gradebook;

public class Student implements Comparable<Student> {
    private String firstName;
    private String lastName;
    private int score;  // Changed to int for test score between 0 and 100

    public Student(String firstName, String lastName, int score) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.score = score;
    }
    
    public String getFirstName() { 
        return firstName; 
    }
    
    public String getLastName() { 
        return lastName; 
    }
    
    public int getScore() { 
        return score; 
    }

    @Override
    public String toString() {
        return firstName + " " + lastName + " " + score;
    }

    @Override
    public int compareTo(Student other) {
        // Compare by test score in descending order:
        if (this.score > other.score) {
            return -1;  // this student comes before the other (higher score)
        } else if (this.score < other.score) {
            return 1;   // this student comes after the other (lower score)
        } else {
            // If scores are equal, you may optionally sort by last name then first name.
            int lastCompare = this.lastName.compareToIgnoreCase(other.lastName);
            if (lastCompare != 0) {
                return lastCompare;
            }
            return this.firstName.compareToIgnoreCase(other.firstName);
        }
    }
}
