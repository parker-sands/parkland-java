/******************************************************************************
*
* Gradebook.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Manages a fixed-size array of Student objects.
* 2. Provides functionality to add a student, sort the student array, and display
*    the current list of students.
* 3. Uses a temporary array for sorting to ensure only the entered students are
*    processed.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Create a Gradebook class that stores an array of Student objects.
* 2. Include:
*    - A Student array to hold student records.
*    - An integer to track the number of students added.
* 3. Provide methods to:
*    - Add a student to the array (addStudent).
*    - Sort the array using the Sorting.selectionSort() method (sort).
*    - Display the array of students (display).
*
******************************************************************************
*
* LAB HINTS
* 1. Do not use an ArrayList; use a standard fixed-size array.
* 2. Maintain a count (numStudents) to track how many students are stored.
* 3. For sorting, create a new array that contains only the current students,
*    then sort this smaller array and copy back the sorted elements.
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Define an array "students" to hold Student objects and an integer "numStudents"
*    to track the count.
* 2. In the constructor, initialize the array with the given capacity and set 
*    numStudents to 0.
* 3. In addStudent():
*    - Check if there is room to add a new student.
*    - Add the student to the array and increment numStudents.
* 4. In sort():
*    - Create a temporary array that only contains the added students.
*    - Use the selectionSort method from the Sorting class to sort the temporary array.
*    - Copy the sorted results back into the original array.
* 5. In display():
*    - Loop through the array for all stored students and print their details.
*
******************************************************************************
*
* INPUT
* 1. Student objects (with first name, last name, and test score)
*
* PROCESSING AND CALCULATIONS
* 1. Add and count Student objects.
* 2. Copy existing students into a temporary array.
* 3. Sort the temporary array using Selection Sort.
* 4. Copy the sorted array back and display results.
*
* OUTPUT
* 1. Sorted list of Student objects displayed to the console.
*
******************************************************************************
*
* PSEUDOCODE - Gradebook Class
*
* CLASS Gradebook
*
* VARIABLES:
*   students : Student[]    // Array to store Student objects.
*   numStudents : int       // Counter for the current number of students.
*
* CONSTRUCTOR: Gradebook(capacity: int)
*   CREATE new Student array "students" with size = capacity.
*   SET numStudents = 0.
*
* METHOD: addStudent(s: Student) -> void
*   IF numStudents < length of students array THEN:
*       SET students[numStudents] = s.
*       INCREMENT numStudents.
*   ELSE:
*       PRINT "Gradebook is full."
*
* METHOD: sort() -> void
*   // Create a temporary array that contains only the added students.
*   CREATE new Student array "temp" with size = numStudents.
*   FOR i FROM 0 TO numStudents - 1 DO:
*       SET temp[i] = students[i].
*   CALL Sorting.selectionSort(temp) to sort the temp array.
*   FOR i FROM 0 TO numStudents - 1 DO:
*       SET students[i] = temp[i].
*
* METHOD: display() -> void
*   FOR i FROM 0 TO numStudents - 1 DO:
*       PRINT students[i].toString()
*
*
******************************************************************************/
package java2_lab_06_sorted_gradebook;

public class Gradebook {
    private Student[] students;  // Array to store Student objects
    private int numStudents;     // Number of students currently in the gradebook

    // Constructor: creates a new Gradebook with a specified capacity
    public Gradebook(int capacity) {
        students = new Student[capacity];
        numStudents = 0;
    }

    // Method: addStudent
    // Adds a Student object to the gradebook if there is room.
    public void addStudent(Student s) {
        if (numStudents < students.length) {
            students[numStudents] = s;
            numStudents++;
        } else {
            System.out.println("Gradebook is full.");
        }
    }

    // Method: sort
    // Creates a temporary array of current Student objects, sorts it, and copies the results back.
    public void sort() {
        // Create a temporary array that contains only the added students.
        Student[] temp = new Student[numStudents];
        for (int i = 0; i < numStudents; i++) {
            temp[i] = students[i];
        }
        // Call the selectionSort method from the Sorting class to sort the temp array
        Sorting.selectionSort(temp);
        // Copy the sorted students back into the original students array
        for (int i = 0; i < numStudents; i++) {
            students[i] = temp[i];
        }
    }

    // Method: display
    // Loops through the array for all stored students and prints their details.
    public void display() {
        for (int i = 0; i < numStudents; i++) {
            System.out.println(students[i]);
        }
    }
}
