/******************************************************************************
*
* SortedGradebook.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Serves as the driver class to run the Sorted Gradebook application.
* 2. Prompts the user to input five students (first name, last name, test score).
* 3. Validates that the test score is between 0 and 100.
* 4. Utilizes the Gradebook class to add, sort, and display student records.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Create a driver class with a main() method.
* 2. Use a Scanner to read user input.
* 3. Instantiate a Gradebook with a capacity for 5 students.
* 4. Loop 5 times:
*    - Prompt for student data: firstName, lastName, and test score.
*    - Validate the test score (must be between 0 and 100).
*    - Create a Student object with the provided data.
*    - Add the Student object to the Gradebook.
* 5. Call the sort() method in Gradebook to arrange students in descending order.
* 6. Display the sorted list of students.
*
******************************************************************************
*
* LAB HINTS
* 1. Use a for-loop that iterates exactly five times.
* 2. In each iteration, check if the entered score is valid. If not, prompt the user
*    again (repeat the current iteration).
* 3. After all valid student entries are added, call Gradebook.sort() followed by
*    Gradebook.display() to show the results.
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Set up a Scanner object to handle input from the console.
* 2. Create a new Gradebook object with a fixed capacity of 5.
* 3. Use a loop to gather user input for each student's first name, last name, and score.
* 4. Validate the test score before creating the Student object. If invalid, repeat the input.
* 5. Add each valid Student to the Gradebook.
* 6. Once all students have been entered, sort them using the Gradebook.sort() method.
* 7. Display the sorted student list using Gradebook.display().
* 8. Close the Scanner.
*
******************************************************************************
*
* INPUT
* 1. Student first name (String)
* 2. Student last name (String)
* 3. Student test score (int; valid range 0–100)
*
* PROCESSING AND CALCULATIONS
* 1. Loop exactly five times to read student details.
* 2. Validate test score input.
* 3. Store each student into the Gradebook.
* 4. Sort the students in descending order by test score using the selection sort method.
*
* OUTPUT
* 1. Print the sorted list of students, each on a new line, in the format:
*    "FirstName LastName Score"
*
******************************************************************************
*
* PSEUDOCODE - Driver Class (SortedGradebook)
*
* CLASS SortedGradebook
*
* METHOD: main(String[] args) -> void
*   CREATE Scanner object "sc" for reading input
*   CREATE Gradebook object "gradebook" with capacity 5
*
*   FOR i FROM 0 TO 4 DO:
*       PRINT "Enter student <firstName> <lastName> <score>: "
*       READ firstName (String)
*       READ lastName (String)
*       READ score (int)
*
*       IF score is less than 0 OR score is greater than 100 THEN:
*           PRINT "Score must be between 0 and 100. Please try again."
*           DECREMENT i (to repeat this iteration)
*           CONTINUE to next iteration
*
*       CREATE new Student object "s" with firstName, lastName, and score
*       CALL gradebook.addStudent(s)
*   END FOR
*
*   CALL gradebook.sort()  // Sort the students by test score in descending order
*   PRINT a blank line and "Sorted Gradebook (Highest to Lowest):"
*   CALL gradebook.display()  // Display the sorted student list
*
*   CLOSE Scanner "sc"
*
******************************************************************************/

package java2_lab_06_sorted_gradebook;

import java.util.Scanner;

public class SortedGradebook {
    public static void main(String[] args) {
        // Create a Scanner object for reading input from the console.
        Scanner sc = new Scanner(System.in);
        
        // Create a Gradebook object with a capacity for 5 students.
        Gradebook gradebook = new Gradebook(5);
        
        // Loop exactly five times to gather student data.
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter student <firstName> <lastName> <score>: ");
            
            // Read the student's first name, last name, and test score.
            String firstName = sc.next();
            String lastName = sc.next();
            int score = sc.nextInt();
            
            // Validate the test score is between 0 and 100.
            if (score < 0 || score > 100) {
                System.out.println("Score must be between 0 and 100. Please try again.");
                i--; // Decrement the counter to repeat this iteration.
                continue;
            }
            
            // Create a Student object with the provided data.
            Student s = new Student(firstName, lastName, score);
            
            // Add the student to the Gradebook.
            gradebook.addStudent(s);
        }
        
        // Sort the Gradebook so that students are ordered by test score in descending order.
        gradebook.sort();
        
        // Display the sorted list of students.
        System.out.println("\nSorted Gradebook (Highest to Lowest):");
        gradebook.display();
        
        // Close the Scanner.
        sc.close();
    }
}
