/******************************************************************************
*
* FoodList.java
*
* Created by: Parker Sands  
* Parkland College  
* CSC-240, JAVA 2  
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Custom singly linked list implementation to store and manage FoodItem objects.
* 2. Provides methods to add, search, print, and (later) remove FoodItems.
* 3. Designed to replicate linked list logic without using Java API collections.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Create a custom linked list class (no ArrayList or LinkedList allowed).
* 2. Must support:
*    - Adding FoodItems
*    - Traversing and printing list
*    - Searching for FoodItem by name
*    - Checking if FoodItem exists
*    - Random food selection (method stub included)
*    - Removal of high-calorie foods (method stub included)
*
******************************************************************************
*
* LAB HINTS
* 1. Use a `head` reference to track the start of the list.
* 2. Each node points to the next until `null`.
* 3. Always check for nulls when traversing.
* 4. Use .equalsIgnoreCase() for string comparisons.
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. This class owns the linked list.
* 2. Adding new items always goes to the end (append style).
* 3. Searching uses a while loop to walk the list.
* 4. Random access requires getting the size and choosing a random index.
* 5. Removal will update internal references to preserve structure.
*
******************************************************************************
*
* INPUT
* 1. FoodItem objects passed in from file or user.
* 2. Food names entered by user for search or selection.
*
* PROCESSING AND CALCULATIONS
* 1. Traverse node-to-node to perform operations.
* 2. Count nodes for size or random selection.
*
* OUTPUT
* 1. Printed list of foods via toString().
*
******************************************************************************
*
* PSEUDOCODE - FoodList Class
*
* CLASS FoodList
*
* VARIABLES:
*   head : FoodNode
*
* METHOD: add(item: FoodItem)
*   IF head is null THEN
*       SET head = new FoodNode(item)
*   ELSE
*       Traverse to end of list
*       Append new node with item
*
* METHOD: printAllFoods()
*   PRINT headings
*   Traverse from head to null
*   PRINT each node’s FoodItem
*
* METHOD: getFoodByName(name: String) -> FoodItem
*   Traverse list
*   IF node.getData().getName().equalsIgnoreCase(name)
*       RETURN node.getData()
*   RETURN null
*
* METHOD: contains(name: String) -> boolean
*   RETURN getFoodByName(name) != null
*
* METHOD: getSize() -> int
*   Traverse and count nodes
*   RETURN count
*
* METHOD: getRandomMeal() -> List<FoodItem>
*   (TO DO)
*
* METHOD: removeHighCalorie(limit: int)
*   (TO DO)
*
******************************************************************************/

package java2_lab_09_food_list;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

public class FoodList {
    private FoodNode head;

    public void add(FoodItem item) {
        FoodNode newNode = new FoodNode(item);
        if (head == null) {
            head = newNode;
        } else {
            FoodNode current = head;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(newNode);
        }
    }

    public void printAllFoods() {
        System.out.println("============================================================================");
        System.out.printf("%-20s %-18s %-18s %s\n", "Name", "Food Group", "Calories", "Daily percentage");
        System.out.println("============================================================================");

        FoodNode current = head;
        while (current != null) {
            System.out.println(current.getData().toString());
            current = current.getNext();
        }
    }
    
    public boolean contains(String name) {
        return getFoodByName(name) != null;
    }

    public FoodItem getFoodByName(String name) {
        FoodNode current = head;
        while (current != null) {
            if (current.getData().getName().equalsIgnoreCase(name)) {
                return current.getData();
            }
            current = current.getNext();
        }
        return null;
    }
    
    public List<FoodItem> getRandomMeal() {
        List<FoodItem> allFoods = new ArrayList<>();
        FoodNode current = head;

        // Step 1: Build a list of all FoodItems
        while (current != null) {
            allFoods.add(current.getData());
            current = current.getNext();
        }

        // Step 2: Randomly pick 3 unique items
        List<FoodItem> result = new ArrayList<>();
        if (allFoods.size() < 3) return result;

        Random rand = new Random();
        HashSet<Integer> chosenIndexes = new HashSet<>();

        while (result.size() < 3) {
            int index = rand.nextInt(allFoods.size());
            if (!chosenIndexes.contains(index)) {
                chosenIndexes.add(index);
                result.add(allFoods.get(index));
            }
        }

        return result;
    }

    public void removeHighCalorie(int limit) {
        // Step 1: Remove from head if needed
        while (head != null && head.getData().getCalories() > limit) {
            head = head.getNext();
        }

        // Step 2: Traverse with two pointers
        FoodNode current = head;
        FoodNode previous = null;

        while (current != null) {
            if (current.getData().getCalories() > limit) {
                if (previous != null) {
                    previous.setNext(current.getNext());
                }
            } else {
                previous = current;
            }
            current = current.getNext();
        }
    }
    
    
}