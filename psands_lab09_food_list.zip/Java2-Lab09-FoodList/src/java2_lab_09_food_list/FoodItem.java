/******************************************************************************
*
* FoodItem.java
*
* Created by: Parker Sands  
* Parkland College  
* CSC-240, JAVA 2  
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Models a single food item containing nutritional information.
* 2. Stores four fields: name, food group, calorie count, and daily percentage.
* 3. Provides accessors and a formatted output method for clean printing.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Create a class to represent a food item from the input file.
* 2. Fields must include:
*    - name (String)
*    - foodGroup (String)
*    - calories (int)
*    - dailyPercent (double)
* 3. Provide:
*    - A constructor to initialize all fields.
*    - Getter methods for each field.
*    - A toString() method that formats the output into aligned columns.
*
******************************************************************************
*
* LAB HINTS
* 1. Use private fields and public getter methods.
* 2. Use String.format in toString() for aligned console output.
* 3. You do not need to round the daily percentage; just format as decimal.
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Keep it simple — this is a data class.
* 2. Constructor sets all four fields on instantiation.
* 3. Getters will be used by the linked list and display methods.
* 4. toString() will be called for display — make it clean and column-friendly.
*
******************************************************************************
*
* INPUT
* 1. Four values per line from the input file:
*    - name, food group, calories, daily percent
*
* PROCESSING AND CALCULATIONS
* 1. Store the values as-is.
* 2. Format them cleanly in toString().
*
* OUTPUT
* 1. Returns a formatted string for aligned table display.
*
******************************************************************************
*
* PSEUDOCODE - FoodItem Class
*
* CLASS FoodItem
*
* VARIABLES:
*   name : String
*   foodGroup : String
*   calories : int
*   dailyPercent : double
*
* CONSTRUCTOR: FoodItem(name: String, foodGroup: String, calories: int, dailyPercent: double)
*   SET this.name = name
*   SET this.foodGroup = foodGroup
*   SET this.calories = calories
*   SET this.dailyPercent = dailyPercent
*
* METHOD: getName() -> String
*   RETURN name
*
* METHOD: getFoodGroup() -> String
*   RETURN foodGroup
*
* METHOD: getCalories() -> int
*   RETURN calories
*
* METHOD: getDailyPercent() -> double
*   RETURN dailyPercent
*
* METHOD: toString() -> String
*   RETURN String.format("%-20s %-18s %-18d %.2f", name, foodGroup, calories, dailyPercent)
*
******************************************************************************/

package java2_lab_09_food_list;

public class FoodItem {
    private String name;
    private String foodGroup;
    private int calories;
    private double dailyPercent;

    public FoodItem(String name, String foodGroup, int calories, double dailyPercent) {
        this.name = name;
        this.foodGroup = foodGroup;
        this.calories = calories;
        this.dailyPercent = dailyPercent;
    }

    public String getName() {
        return name;
    }

    public String getFoodGroup() {
        return foodGroup;
    }

    public int getCalories() {
        return calories;
    }

    public double getDailyPercent() {
        return dailyPercent;
    }

    @Override
    public String toString() {
        return String.format("%-20s %-18s %-18d %.2f", name, foodGroup, calories, dailyPercent);
    }
}
