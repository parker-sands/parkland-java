/******************************************************************************
*
* MealPlanner.java
*
* Created by: Parker Sands  
* Parkland College  
* CSC-240, JAVA 2  
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Driver class for the Meal Planning system using a custom linked list.
* 2. Reads food items from a file and stores them in a FoodList.
* 3. Presents a menu for user interaction: list, manual/random meal, remove items.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Read data from file and create FoodItem objects.
* 2. Add FoodItems to a custom FoodList (linked list).
* 3. Present a menu:
*    - List all food items
*    - Create meal manually
*    - Create meal randomly
*    - Remove high-calorie foods
*    - Exit
* 4. Handle I/O exceptions with try/catch.
*
******************************************************************************
*
* LAB HINTS
* 1. Use Scanner with File to read the input.
* 2. Use a while loop for the main menu.
* 3. Use FoodList methods for all operations.
* 4. For manual meal creation, validate food names using contains().
* 5. Use a loop until three valid items are added to the meal.
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Setup file reading with try/catch and Scanner.
* 2. Load FoodList at program start.
* 3. Loop through menu choices with input validation.
* 4. Offload actual data logic to FoodList.
* 5. Clean up formatting for console clarity.
*
******************************************************************************
*
* INPUT
* 1. foods.txt file (same folder as project or via Eclipse import)
* 2. User menu selections and typed food names
*
* PROCESSING AND CALCULATIONS
* 1. File parsing and FoodItem construction
* 2. Menu interaction and food selection logic
*
* OUTPUT
* 1. Menu display, food list, meal output, confirmation messages
*
******************************************************************************
*
* PSEUDOCODE - MealPlanner Driver Class
*
* MAIN METHOD:
*   CREATE FoodList
*   READ file with try/catch
*     FOR each line:
*       PARSE values
*       CREATE FoodItem
*       ADD to FoodList
*
*   WHILE user does not exit
*     DISPLAY menu
*     GET user choice
*     SWITCH based on input:
*       1 - Print all foods
*       2 - Manual meal selection
*       3 - Random meal selection
*       4 - Remove high-calorie foods
*       5 - Exit
*
******************************************************************************/

package java2_lab_09_food_list;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class MealPlanner {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        FoodList foodList = new FoodList();

        // Load food database from file
        try {
            Scanner fileScanner = new Scanner(new File("foods.txt"));
            while (fileScanner.hasNext()) {
                String name = fileScanner.next();
                String group = fileScanner.next();
                int calories = fileScanner.nextInt();
                double percent = fileScanner.nextDouble();

                FoodItem item = new FoodItem(name, group, calories, percent);
                foodList.add(item);
            }
            fileScanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error: foods.txt file not found.");
            return;
        } catch (Exception e) {
            System.out.println("Error while reading file: " + e.getMessage());
            return;
        }

        int choice = 0;
        while (choice != 5) {
            System.out.println("\n---------------------------------");
            System.out.println("Welcome to Parkland Meal Selector");
            System.out.println("---------------------------------");
            System.out.println("Please select from the following");
            System.out.println("1 - List food database");
            System.out.println("2 - Create meal by manual selection");
            System.out.println("3 - Create meal by random selection");
            System.out.println("4 - Remove foods high in calorie");
            System.out.println("5 - Exit");
            System.out.print("Your choice: ");

            if (input.hasNextInt()) {
                choice = input.nextInt();
                input.nextLine(); // consume leftover newline

                switch (choice) {
                    case 1:
                        foodList.printAllFoods();
                        break;
                    case 2:
                        createManualMeal(input, foodList);
                        break;
                    case 3:
                        createRandomMeal(foodList);
                        break;
                    case 4:
                        removeHighCalorieFoods(input, foodList);
                        break;
                    case 5:
                        System.out.println("Exiting... Enjoy your meal!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter 1–5.");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                input.nextLine(); // clear invalid input
            }
        }

        input.close();
    }

    public static void createManualMeal(Scanner input, FoodList list) {
        List<FoodItem> meal = new ArrayList<>();
        while (meal.size() < 3) {
            System.out.print("Enter food name: ");
            String name = input.nextLine();

            if (list.contains(name)) {
                FoodItem item = list.getFoodByName(name);
                meal.add(item);
            } else {
                System.out.println("Food " + name + " not in database, try again");
            }
        }

        printMeal(meal, "Your selected meal");
    }

    public static void createRandomMeal(FoodList list) {
        List<FoodItem> meal = list.getRandomMeal();

        if (meal.size() < 3) {
            System.out.println("Not enough foods to generate a random meal.");
        } else {
            printMeal(meal, "Your selected meal");
        }
    }

    public static void removeHighCalorieFoods(Scanner input, FoodList list) {
        System.out.print("Enter calorie limit: ");
        if (input.hasNextInt()) {
            int limit = input.nextInt();
            input.nextLine(); // consume newline
            list.removeHighCalorie(limit);
            System.out.println("Foods over " + limit + " calories have been removed.");
        } else {
            System.out.println("Invalid input. Please enter a number.");
            input.nextLine(); // clear invalid
        }
    }

    public static void printMeal(List<FoodItem> meal, String header) {
        int totalCalories = 0;
        double totalPercent = 0.0;

        System.out.println("\n===============================");
        System.out.println(header);

        System.out.print("Foods: ");
        for (int i = 0; i < meal.size(); i++) {
            FoodItem item = meal.get(i);
            System.out.print(item.getName());
            if (i < meal.size() - 1) System.out.print(" ");
            totalCalories += item.getCalories();
            totalPercent += item.getDailyPercent();
        }

        System.out.println("\nTotal calorie count: " + totalCalories);
        System.out.printf("Total daily percentage: %.0f%%\n", totalPercent * 100);
        System.out.println("===============================");
    }
}
