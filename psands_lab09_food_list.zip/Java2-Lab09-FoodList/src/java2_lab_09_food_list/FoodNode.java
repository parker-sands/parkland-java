/******************************************************************************
*
* FoodNode.java
*
* Created by: Parker Sands  
* Parkland College  
* CSC-240, JAVA 2  
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Represents a node in a singly linked list of food items.
* 2. Stores a reference to a FoodItem object and the next node in the list.
* 3. Used internally by the FoodList class to build and manage the list structure.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Create a class to represent a node in a custom linked list.
* 2. Each node should contain:
*    - a FoodItem object (the data)
*    - a reference to the next FoodNode in the list
* 3. Provide:
*    - A constructor that accepts a FoodItem
*    - Getters and setters for both fields
*
******************************************************************************
*
* LAB HINTS
* 1. This class does not need to implement any logic itself — just data linking.
* 2. Keep fields private and use accessors/mutators.
* 3. You can leave toString() out — the FoodItem already has one.
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Mimic the textbook pattern for a basic singly linked list node.
* 2. This is the building block for FoodList.
* 3. Constructor sets the data, next starts as null.
*
******************************************************************************
*
* INPUT
* 1. FoodItem object passed to constructor.
*
* PROCESSING AND CALCULATIONS
* 1. No calculations — just reference linking.
*
* OUTPUT
* 1. None directly — methods provide access to node data and link.
*
******************************************************************************
*
* PSEUDOCODE - FoodNode Class
*
* CLASS FoodNode
*
* VARIABLES:
*   data : FoodItem
*   next : FoodNode
*
* CONSTRUCTOR: FoodNode(data: FoodItem)
*   SET this.data = data
*   SET this.next = null
*
* METHOD: getData() -> FoodItem
*   RETURN data
*
* METHOD: getNext() -> FoodNode
*   RETURN next
*
* METHOD: setNext(next: FoodNode)
*   SET this.next = next
*
******************************************************************************/
package java2_lab_09_food_list;

public class FoodNode {
    private FoodItem data;
    private FoodNode next;

    public FoodNode(FoodItem data) {
        this.data = data;
        this.next = null;
    }

    public FoodItem getData() {
        return data;
    }

    public FoodNode getNext() {
        return next;
    }

    public void setNext(FoodNode next) {
        this.next = next;
    }
}
