/******************************************************************************
*
* AutoPolicy.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Represents an Auto insurance policy.
* 2. Inherits common policy attributes from `Policy`.
* 3. Implements `computeCommission()` to calculate commission for auto policies.
*
******************************************************************************
* 
* LAB INSTRUCTIONS
* 1. Make `AutoPolicy` a subclass of `Policy` (`extends Policy`).
* 2. Implement a constructor to initialize values.
* 3. Override `computeCommission()` to return 7% of premium amount.
*
******************************************************************************
*
* LAB HINTS
* 1. Use `super()` in the constructor to call `Policy`'s constructor.
* 2. Override `computeCommission()` to apply the 30% commission rate.
* 3. Ensure compatibility with `CommissionCalculator` for calculations.
* 
******************************************************************************
*
* EXAMPLE PROGRAM OUTPUT (Generated from CommissionCalculator)
* Auto Policy
* -----------
* Policy Holder: Jerry
* Policy Number: A123
* Premium Amount: $1000.00
* Commission: $300.00
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Define `AutoPolicy` as a subclass (`extends Policy`).
* 2. Implement a constructor that calls `super()` to initialize values.
* 3. Override `computeCommission()` to return `premiumAmount * 0.30`.
* 4. Ensure the class interacts properly with `CommissionCalculator`.
* 
******************************************************************************
*
* INPUT
* 1. Policy details (policy number, holder name, premium amount) provided
*    via constructor.
* 
* PROCESSING AND CALCULATIONS
* 1. Compute commission as 30% of premium amount.
* 
* OUTPUT
* 1. Displays policyholder details and calculated commission.
* 
*****************************************************************************/
package java2_lab_03_commission_calculator_inheritance;

public class AutoPolicy extends Policy {
    private String make;
    private String model;
    private double liability;
    private double collision;

    public AutoPolicy(String policyNumber, String policyHolderName, String make, String model, double liability, double collision) {
        super(policyNumber, policyHolderName, liability + collision);
        this.make = make;
        this.model = model;
        this.liability = liability;
        this.collision = collision;
    }

    @Override
    public double computeCommission() {
        return this.premiumAmount * 0.30;
    }
}