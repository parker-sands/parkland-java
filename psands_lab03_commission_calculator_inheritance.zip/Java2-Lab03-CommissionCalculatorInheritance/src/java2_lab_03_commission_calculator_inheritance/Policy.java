/******************************************************************************
*
* Policy.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Serves as an abstract base class for insurance policies.
* 2. Stores common attributes: policy number, policyholder name, premium amount.
* 3. Defines an abstract method `computeCommission()` for subclasses to implement.
* 4. Provides getters to retrieve policy details.
*
******************************************************************************
* 
* LAB INSTRUCTIONS
* 1. Create an abstract class `Policy` to serve as the parent class.
* 2. Include shared attributes**: `policyNumber`, `policyHolderName`, 
*    `premiumAmount`.
* 3. Implement a constructor** for initializing common fields.
* 4. Provide getter methods** for retrieving policy details.
* 5. Declare an abstract method `computeCommission()` to be overridden 
*    in subclasses.
* 
******************************************************************************
*
* LAB HINTS
* 1. Use the `abstract` keyword to prevent instantiation of `Policy`.
* 2. Declare `computeCommission()` as **abstract** to enforce implementation 
*    in subclasses.
* 3. Use protected visibility for instance variables to allow subclass 
*    access.
* 4. Provide a constructor to initialize values upon object creation.
* 5. Ensure subclasses (`AutoPolicy`, `HomePolicy`, `LifePolicy`) extend 
*    `Policy`.
* 
******************************************************************************
*
* EXAMPLE PROGRAM OUTPUT (Generated from CommissionCalculator)
* Policy Summary:
* ---------------
* Policy Holder: Jerry
* Policy Number: A123
* Premium Amount: $1500.00
* Commission: $105.00
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Define abstract class `Policy` with shared insurance attributes.
* 2. Implement a constructor to initialize values.
* 3. Provide getter methods for encapsulation.
* 4. Declare `computeCommission()` as abstract (forcing subclass 
*    implementation).
* 5. Ensure `Policy` is inherited by `AutoPolicy`, `HomePolicy`, and `LifePolicy`.
* 
******************************************************************************
*
* INPUT
* 1. Policy details (policy number, holder name, premium amount) will be passed
*    via constructors.
* 
* PROCESSING AND CALCULATIONS
* 1. `computeCommission()` will be implemented by subclasses based on policy type.
* 
* OUTPUT
* 1. Displays policyholder details and calculated commission when requested.
* 
*****************************************************************************/
package java2_lab_03_commission_calculator_inheritance;

abstract class Policy {
    protected String policyNumber;
    protected String policyHolderName;
    protected double premiumAmount;

    // Constructor
    public Policy(String policyNumber, String policyHolderName, 
    		double premiumAmount) {
        this.policyNumber = policyNumber;
        this.policyHolderName = policyHolderName;
        this.premiumAmount = premiumAmount;
    }

    // Getters
    public String getPolicyNumber() { return policyNumber; }
    public String getPolicyHolderName() { return policyHolderName; }
    public double getPremiumAmount() { return premiumAmount; }
    
    public String toString() {
    	return "Policy Number: " + policyNumber + "\nPolicy Holder: " 
    + policyHolderName;
    }

    // Abstract method that subclasses must implement
    public abstract double computeCommission();  
}
