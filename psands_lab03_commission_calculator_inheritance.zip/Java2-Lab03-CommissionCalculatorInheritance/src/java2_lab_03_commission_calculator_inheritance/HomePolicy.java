/******************************************************************************
*
* HomePolicy.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Represents a Home insurance policy.
* 2. Inherits common policy attributes from `Policy`.
* 3. Implements `computeCommission()` to calculate commission for home policies.
*
******************************************************************************
* 
* LAB INSTRUCTIONS
* 1. Make `HomePolicy` a subclass of `Policy` (`extends Policy`).
* 2. Implement a constructor to initialize values.
* 3. Override `computeCommission()` to return 20% of premium amount.
*
******************************************************************************
*
* LAB HINTS
* 1. Use `super()` in the constructor to call `Policy`'s constructor.
* 2. Override `computeCommission()` to apply the 20% commission rate.
* 3. Ensure compatibility with `CommissionCalculator` for calculations.
* 
******************************************************************************
*
* EXAMPLE PROGRAM OUTPUT (Generated from CommissionCalculator)
* Home Policy
* -----------
* Policy Holder: Jerry
* Policy Number: H456
* Premium Amount: $1000.00
* Commission: $200.00
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Define `HomePolicy` as a subclass (`extends Policy`).
* 2. Implement a constructor that calls `super()` to initialize values.
* 3. Override `computeCommission()` to return `premiumAmount * 0.2`.
* 4. Ensure the class interacts properly with `CommissionCalculator`.
* 
******************************************************************************
*
* INPUT
* 1. Policy details (policy number, holder name, premium amount) provided 
*    via constructor.
* 
* PROCESSING AND CALCULATIONS
* 1. Compute commission as 20% of premium amount.
* 
* OUTPUT
* 1. Displays policyholder details and calculated commission.
* 
*****************************************************************************/
package java2_lab_03_commission_calculator_inheritance;

public class HomePolicy extends Policy {
    private int squareFootage;
    private double dwelling;
    private double contents;
    private double liability;

    public HomePolicy(String policyNumber, String policyHolderName, int squareFootage, double dwelling, double contents, double liability) {
        super(policyNumber, policyHolderName, dwelling + contents + liability);
        this.squareFootage = squareFootage;
        this.dwelling = dwelling;
        this.contents = contents;
        this.liability = liability;
    }

    @Override
    public double computeCommission() {
        return this.premiumAmount * 0.20;
    }
}
