/******************************************************************************
*
* CommissionCalculator.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Manages insurance policy entries and commission calculations.
* 2. Uses **polymorphism** by storing all policies (`AutoPolicy`, `HomePolicy`, `LifePolicy`) 
*    in an `ArrayList<Policy>`.
* 3. Provides a **menu-driven interface** to:
*    - Add different types of policies.
*    - Print all entered policies and their commissions.
* 4. Demonstrates **dynamic method calls**:
*    - Calls `computeCommission()` on each policy dynamically.
*    - Calls `toString()` for proper policy display.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Modify `CommissionCalculator` to store policies in an `ArrayList<Policy>`.
* 2. Implement a **menu-driven loop** to:
*    - Prompt users to enter **Auto, Home, or Life insurance policies**.
*    - Store each policy in the `ArrayList<Policy>`.
*    - Print all policies when requested.
* 3. Iterate through the list using **polymorphism** to compute commissions.
*
******************************************************************************
*
* LAB HINTS
* 1. Use an `ArrayList<Policy>` to store policies.
* 2. Utilize a `do-while` loop for the menu-driven interface.
* 3. Ensure that `computeCommission()` and `toString()` work dynamically.
* 4. Use a `for-each` loop to iterate through policies and compute commissions.
*
******************************************************************************
*
* EXAMPLE PROGRAM OUTPUT
* -----------------------------
* Welcome to Parkland Insurance
* -----------------------------
* 1) Enter auto insurance policy information
* 2) Enter home insurance policy information
* 3) Enter life insurance policy information
* 4) Print all sales entered
* 5) Quit
* Enter choice: 4
*
* Auto Policy
* -----------
* Policy Holder: Jerry
* Policy Number: A123
* Make: Toyota
* Model: Corolla
* Liability: $500.00
* Collision: $500.00
* Commission: $300.00
*
* Home Policy
* -----------
* Policy Holder: Elaine
* Policy Number: H456
* Square Footage: 2000
* Dwelling Coverage: $150,000.00
* Contents Coverage: $50,000.00
* Liability Coverage: $100,000.00
* Commission: $40,000.00
*
* Life Policy
* -----------
* Policy Holder: Cosmo
* Policy Number: L789
* Age: 45
* Term Life Coverage: $250,000.00
* Commission: $50,000.00
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Define `CommissionCalculator` as the **main program driver**.
* 2. Declare an `ArrayList<Policy>` to store different types of policies.
* 3. Implement a `do-while` loop to provide a **menu-driven user interface**:
*       - **Option 1:** Prompt user for Auto Policy details → Create `AutoPolicy` → Add to list.
*       - **Option 2:** Prompt user for Home Policy details → Create `HomePolicy` → Add to list.
*       - **Option 3:** Prompt user for Life Policy details → Create `LifePolicy` → Add to list.
*       - **Option 4:** Print all stored policies using a `for-each` loop.
*       - **Option 5:** Quit the program.
* 4. Ensure `computeCommission()` is **called dynamically** using polymorphism.
* 5. Ensure `toString()` provides clear formatted output for each policy.
*
******************************************************************************
*
* INPUT
* 1. User selects a menu option (1-5).
* 2. If entering a policy:
*    - **Auto Policy:** Policy Number, Name, Make, Model, Liability, Collision.
*    - **Home Policy:** Policy Number, Name, Square Footage, Dwelling, Contents, Liability.
*    - **Life Policy:** Policy Number, Name, Age, Term Life Coverage.
*
* PROCESSING AND CALCULATIONS
* 1. Stores policies in an `ArrayList<Policy>`.
* 2. Computes commissions dynamically by iterating through the list.
*
* OUTPUT
* 1. Displays all stored policies and their commissions when requested.
*
*****************************************************************************/
package java2_lab_04_commission_calculator_polymorphism;

import java.util.ArrayList;
import java.util.Scanner;

public class CommissionCalculator {
    private ArrayList<Policy> policies = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    // Main method to start the program
    public static void main(String[] args) {
        CommissionCalculator calculator = new CommissionCalculator();
        calculator.start();
    }

    // Method to handle user interaction via menu-driven interface
    public void start() {
    	int choice = -1;  // Default value to avoid compilation errors
    	do {
    	    System.out.println("\n-----------------------------");
    	    System.out.println("Welcome to Parkland Insurance");
    	    System.out.println("-----------------------------");
    	    System.out.println("1) Enter auto insurance policy information");
    	    System.out.println("2) Enter home insurance policy information");
    	    System.out.println("3) Enter life insurance policy information");
    	    System.out.println("4) Print all sales entered");
    	    System.out.println("5) Quit");
    	    System.out.print("Enter choice: ");

    	    if (scanner.hasNextInt()) {
    	        choice = scanner.nextInt();
    	        scanner.nextLine(); // Consume newline
    	    } else {
    	        System.out.println("\nInvalid input. Please enter a number between 1 and 5.");
    	        scanner.nextLine(); // Consume invalid input
    	        continue;
    	    }

    	    switch (choice) {
    	        case 1:
    	            enterAutoPolicy();
    	            break;
    	        case 2:
    	            enterHomePolicy();
    	            break;
    	        case 3:
    	            enterLifePolicy();
    	            break;
    	        case 4:
    	            printAllPolicies();
    	            break;
    	        case 5:
    	            System.out.println("Exiting program...");
    	            break;
    	        default:
    	            System.out.println("Invalid choice! Try again.");
    	    }
    	} while (choice != 5);
    	}

    // Method to enter Auto Policy
    private void enterAutoPolicy() {
        System.out.print("Enter Policy Number: ");
        String policyNumber = scanner.nextLine();
        System.out.print("Enter Policy Holder Name: ");
        String holderName = scanner.nextLine();
        System.out.print("Enter Make of Vehicle: ");
        String make = scanner.nextLine();
        System.out.print("Enter Model of Vehicle: ");
        String model = scanner.nextLine();
        System.out.print("Enter Liability Coverage Amount: ");
        double liability = validateDoubleInput();
        System.out.print("Enter Collision Coverage Amount: ");
        double collision = validateDoubleInput();

        policies.add(new AutoPolicy(policyNumber, holderName, make, model, liability, collision));
        System.out.println("✅ Auto Policy Added Successfully.");
    }

    // Method to enter Home Policy
    private void enterHomePolicy() {
        System.out.print("Enter Policy Number: ");
        String policyNumber = scanner.nextLine();
        System.out.print("Enter Policy Holder Name: ");
        String holderName = scanner.nextLine();
        System.out.print("Enter House Square Footage: ");
        int squareFootage = validateIntInput();
        System.out.print("Enter Dwelling Coverage Amount: ");
        double dwelling = validateDoubleInput();
        System.out.print("Enter Contents Coverage Amount: ");
        double contents = validateDoubleInput();
        System.out.print("Enter Liability Coverage Amount: ");
        double liability = validateDoubleInput();

        policies.add(new HomePolicy(policyNumber, holderName, squareFootage, dwelling, contents, liability));
        System.out.println("✅ Home Policy Added Successfully.");
    }

    // Method to enter Life Policy
    private void enterLifePolicy() {
        System.out.print("Enter Policy Number: ");
        String policyNumber = scanner.nextLine();
        System.out.print("Enter Policy Holder Name: ");
        String holderName = scanner.nextLine();
        System.out.print("Enter Age of Insured: ");
        int age = validateIntInput();
        System.out.print("Enter Term Life Coverage Amount: ");
        double termCoverage = validateDoubleInput();

        policies.add(new LifePolicy(policyNumber, holderName, age, termCoverage));
        System.out.println("✅ Life Policy Added Successfully.");
    }

    // Method to print all policies and compute commissions dynamically
    private void printAllPolicies() {
        if (policies.isEmpty()) {
            System.out.println("⚠️ No policies entered yet.");
            return;
        }

        System.out.println("\n-------- All Policies --------");
        for (Policy policy : policies) {
            policy.computeCommission();  // Demonstrating polymorphism
            System.out.println(policy);
        }
    }

    // Helper method to validate double input
    private double validateDoubleInput() {
        while (true) {
            if (scanner.hasNextDouble()) {
                double value = scanner.nextDouble();
                scanner.nextLine(); // Consume newline
                return value;
            } else {
                System.out.println("Invalid input. Please enter a valid numeric value.");
                scanner.nextLine(); // Consume invalid input
            }
        }
    }

    // Helper method to validate integer input
    private int validateIntInput() {
        while (true) {
            if (scanner.hasNextInt()) {
                int value = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                return value;
            } else {
                System.out.println("Invalid input. Please enter a valid integer value.");
                scanner.nextLine(); // Consume invalid input
            }
        }
    }
}