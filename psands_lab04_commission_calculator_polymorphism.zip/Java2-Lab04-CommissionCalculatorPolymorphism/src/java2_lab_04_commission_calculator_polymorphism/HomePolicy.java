/******************************************************************************
*
* HomePolicy.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Represents a Home insurance policy.
* 2. Inherits common policy attributes from `Policy`.
* 3. Implements `computeCommission()` to calculate commission for home policies.
* 4. Overrides `toString()` to provide a formatted output for policy details.
* 5. Demonstrates **polymorphism** by allowing `computeCommission()` and 
*    `toString()` to be called dynamically via a `Policy` reference.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Make `HomePolicy` a subclass of `Policy` (`extends Policy`).
* 2. Implement a constructor to initialize values.
* 3. Override `computeCommission()` to return **30% of liability + 20% of (dwelling + contents)**.
* 4. Ensure that `toString()` provides a formatted policy summary.
*
******************************************************************************
*
* LAB HINTS
* 1. Use `super()` in the constructor to call `Policy`'s constructor.
* 2. Compute commission as **(liability * 30%) + ((dwelling + contents) * 20%)**.
* 3. Override `toString()` to include home-specific details.
* 4. Ensure compatibility with `CommissionCalculator` for **dynamic method calls**.
*
******************************************************************************
*
* EXAMPLE PROGRAM OUTPUT (Generated from `CommissionCalculator`)
* Home Policy
* -----------
* Policy Holder: Jerry
* Policy Number: H456
* Square Footage: 2000
* Dwelling Coverage: $150,000.00
* Contents Coverage: $50,000.00
* Liability Coverage: $100,000.00
* Commission: $40,000.00
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Define `HomePolicy` as a subclass (`extends Policy`) to inherit common policy attributes.
* 2. Implement a constructor that calls `super()` to initialize the policy number, 
*    policy holder name, and total coverage amount (dwelling + contents + liability).
* 3. Override `computeCommission()` to return:
*       - **30% of liability**
*       - **20% of (dwelling + contents)**
* 4. Override `toString()` to display all policy details, including square footage, 
*    dwelling, contents, and liability.
* 5. Ensure that `computeCommission()` and `toString()` can be called dynamically when iterating 
*    through an `ArrayList<Policy>` in `CommissionCalculator`.
*
******************************************************************************
*
* INPUT
* 1. Policy details:
*    - Policy Number (String)
*    - Policy Holder Name (String)
*    - House Square Footage (int)
*    - Dwelling Coverage (double)
*    - Contents Coverage (double)
*    - Liability Coverage (double)
*
* PROCESSING AND CALCULATIONS
* 1. Compute the total coverage: `dwelling + contents + liability`.
* 2. Compute commission as **(liability * 30%) + ((dwelling + contents) * 20%)**.
*
* OUTPUT
* 1. Displays policyholder details, home coverage amounts, and calculated commission.
*
*****************************************************************************/
package java2_lab_04_commission_calculator_polymorphism;

public class HomePolicy extends Policy {
    private int squareFootage;
    private double dwelling;
    private double contents;
    private double liability;

    // Constructor to initialize policy details
    public HomePolicy(String policyNumber, String policyHolderName, int squareFootage, double dwelling, double contents, double liability) {
        super(policyNumber, policyHolderName, dwelling + contents + liability);  // Total coverage
        this.squareFootage = squareFootage;
        this.dwelling = dwelling;
        this.contents = contents;
        this.liability = liability;
    }

    // Override computeCommission() using the formula: (liability * 30%) + ((dwelling + contents) * 20%)
    @Override
    public double computeCommission() {
        return (liability * 0.30) + ((dwelling + contents) * 0.20);
    }

    // Override toString() to provide a formatted display of the policy details
    @Override
    public String toString() {
        return super.toString() +
               "\nSquare Footage: " + squareFootage +
               "\nDwelling Coverage: $" + String.format("%.2f", dwelling) +
               "\nContents Coverage: $" + String.format("%.2f", contents) +
               "\nLiability Coverage: $" + String.format("%.2f", liability) +
               "\nCommission: $" + String.format("%.2f", computeCommission()) + "\n";
    }
}
