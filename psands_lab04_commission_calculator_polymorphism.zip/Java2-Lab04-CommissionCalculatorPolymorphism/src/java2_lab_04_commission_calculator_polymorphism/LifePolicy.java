/******************************************************************************
*
* LifePolicy.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Represents a Life insurance policy.
* 2. Inherits common policy attributes from `Policy`.
* 3. Implements `computeCommission()` to calculate commission for life policies.
* 4. Overrides `toString()` to provide a formatted output for policy details.
* 5. Demonstrates **polymorphism** by allowing `computeCommission()` and 
*    `toString()` to be called dynamically via a `Policy` reference.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Make `LifePolicy` a subclass of `Policy` (`extends Policy`).
* 2. Implement a constructor to initialize values.
* 3. Override `computeCommission()` to return **20% of the term life coverage amount**.
* 4. Ensure that `toString()` provides a formatted policy summary.
*
******************************************************************************
*
* LAB HINTS
* 1. Use `super()` in the constructor to call `Policy`'s constructor.
* 2. Compute commission as **20% of term life coverage**.
* 3. Override `toString()` to include life insurance-specific details.
* 4. Ensure compatibility with `CommissionCalculator` for **dynamic method calls**.
*
******************************************************************************
*
* EXAMPLE PROGRAM OUTPUT (Generated from `CommissionCalculator`)
* Life Policy
* -----------
* Policy Holder: Jerry
* Policy Number: L789
* Age: 45
* Term Life Coverage: $250,000.00
* Commission: $50,000.00
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Define `LifePolicy` as a subclass (`extends Policy`) to inherit common policy attributes.
* 2. Implement a constructor that calls `super()` to initialize the policy number, 
*    policy holder name, and total term life coverage amount.
* 3. Override `computeCommission()` to return **20% of term life coverage**.
* 4. Override `toString()` to display all policy details, including the age of the insured 
*    and term life coverage.
* 5. Ensure that `computeCommission()` and `toString()` can be called dynamically when iterating 
*    through an `ArrayList<Policy>` in `CommissionCalculator`.
*
******************************************************************************
*
* INPUT
* 1. Policy details:
*    - Policy Number (String)
*    - Policy Holder Name (String)
*    - Age of Insured (int)
*    - Term Life Coverage Amount (double)
*
* PROCESSING AND CALCULATIONS
* 1. Compute the total coverage: `term life coverage amount`.
* 2. Compute commission as **20% of term life coverage**.
*
* OUTPUT
* 1. Displays policyholder details, term life coverage, and calculated commission.
*
*****************************************************************************/
package java2_lab_04_commission_calculator_polymorphism;

public class LifePolicy extends Policy {
    private int age;
    private double termCoverage;

    // Constructor to initialize policy details
    public LifePolicy(String policyNumber, String policyHolderName, int age, double termCoverage) {
        super(policyNumber, policyHolderName, termCoverage);  // Total coverage
        this.age = age;
        this.termCoverage = termCoverage;
    }

    // Override computeCommission() using the formula: term life * 20%
    @Override
    public double computeCommission() {
        return termCoverage * 0.20;
    }

    // Override toString() to provide a formatted display of the policy details
    @Override
    public String toString() {
        return super.toString() +
               "\nAge: " + age +
               "\nTerm Life Coverage: $" + String.format("%.2f", termCoverage) +
               "\nCommission: $" + String.format("%.2f", computeCommission()) + "\n";
    }
}
