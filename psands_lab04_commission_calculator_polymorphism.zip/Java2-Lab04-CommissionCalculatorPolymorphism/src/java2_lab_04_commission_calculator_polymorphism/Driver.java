/******************************************************************************
*
* Driver.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Serves as the **entry point** for the program.
* 2. Creates an instance of `CommissionCalculator` and starts the menu-driven system.
* 3. Ensures clean separation between the **main driver** and the **business logic** 
*    handled in `CommissionCalculator.java`.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Implement `Driver.java` as the **starting point** for the program.
* 2. The `main()` method should:
*    - Create an instance of `CommissionCalculator`.
*    - Call `.start()` to begin the menu-driven interaction.
* 3. No additional logic should be present in `Driver.java`—it only **starts the program**.
*
******************************************************************************
*
* LAB HINTS
* 1. Keep `Driver.java` minimal—only initialize and call `.start()`.
* 2. All policy management and commission calculations should occur in `CommissionCalculator.java`.
*
******************************************************************************
*
* EXAMPLE PROGRAM OUTPUT (upon running `Driver.java`)
* -----------------------------
* Welcome to Parkland Insurance
* -----------------------------
* 1) Enter auto insurance policy information
* 2) Enter home insurance policy information
* 3) Enter life insurance policy information
* 4) Print all sales entered
* 5) Quit
* Enter choice: _
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Define `Driver.java` as the **entry point** of the program.
* 2. Implement the `main()` method to:
*       - Create a `CommissionCalculator` object.
*       - Call `.start()` to begin the user menu interaction.
* 3. Ensure that `Driver.java` contains **no business logic**—only initialization.
*
******************************************************************************
*
* INPUT
* 1. No user input is handled in `Driver.java`.
* 2. User input is managed in `CommissionCalculator.java` after calling `.start()`.
*
* PROCESSING
* 1. `main()` method executes.
* 2. `CommissionCalculator` object is created.
* 3. `.start()` method runs, launching the menu system.
*
* OUTPUT
* 1. The user sees the menu-driven interface from `CommissionCalculator`.
*
*****************************************************************************/
package java2_lab_04_commission_calculator_polymorphism;

public class Driver {
    public static void main(String[] args) {
        // Create an instance of CommissionCalculator and start the program
        CommissionCalculator calculator = new CommissionCalculator();
        calculator.start();
    }
}
