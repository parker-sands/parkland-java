/******************************************************************************
*
* Policy.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Serves as an **abstract base class** for all insurance policies.
* 2. Defines **common attributes** shared across all policy types:
*    - Policy Number
*    - Policy Holder Name
*    - Premium Amount (total coverage amount)
* 3. Enforces **polymorphism** by defining `computeCommission()` as an 
*    **abstract method**, requiring subclasses to implement their own versions.
* 4. Provides a `toString()` method for displaying **common policy details**.
* 5. Allows **dynamic method dispatch**, enabling polymorphic behavior when 
*    iterating through an `ArrayList<Policy>` in `CommissionCalculator`.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Make `Policy` an **abstract class**.
* 2. Declare **protected attributes** for `policyNumber`, `policyHolderName`, 
*    and `premiumAmount` to be inherited by subclasses.
* 3. Provide a **constructor** to initialize common fields.
* 4. Declare `computeCommission()` as an **abstract method** so that each 
*    subclass must implement its own version.
* 5. Override `toString()` to return a **formatted string** of policy details.
*
******************************************************************************
*
* LAB HINTS
* 1. Mark the class as `abstract` to prevent direct instantiation.
* 2. Use `super()` in subclass constructors to initialize shared attributes.
* 3. Keep `computeCommission()` **abstract** (no implementation in `Policy`).
* 4. Ensure that `toString()` only prints **common fields**; subclasses will
*    override it to add specific details.
*
******************************************************************************
*
* EXAMPLE PROGRAM OUTPUT (Base Class Portion)
* --------------------------------------------
* Policy Number: A123
* Policy Holder: Jerry
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Define `Policy` as an **abstract class** to ensure it cannot be instantiated.
* 2. Include shared attributes **policyNumber, policyHolderName, and premiumAmount**.
* 3. Implement a **constructor** that initializes these values.
* 4. Declare `computeCommission()` as **abstract**, requiring subclasses to
*    provide their own implementation.
* 5. Override `toString()` to return a formatted **policy summary**.
* 6. Ensure that `computeCommission()` and `toString()` can be called 
*    **dynamically** when iterating through an `ArrayList<Policy>` in 
*    `CommissionCalculator` (demonstrating **polymorphism**).
*
******************************************************************************
*
* INPUT
* 1. **Policy details (from constructor)**:
*    - Policy Number (String)
*    - Policy Holder Name (String)
*    - Premium Amount (double) (total coverage value)
*
* PROCESSING AND CALCULATIONS
* 1. Store policy details in instance variables.
* 2. Allow subclasses to define how commissions are calculated.
*
* OUTPUT
* 1. Displays common policy details (policy number & holder name).
*
*****************************************************************************/
package java2_lab_04_commission_calculator_polymorphism;

// Abstract class serving as a base for all policy types
public abstract class Policy {
    protected String policyNumber;
    protected String policyHolderName;
    protected double premiumAmount;

    // Constructor to initialize shared attributes
    public Policy(String policyNumber, String policyHolderName, double premiumAmount) {
        this.policyNumber = policyNumber;
        this.policyHolderName = policyHolderName;
        this.premiumAmount = premiumAmount;
    }

    // Abstract method to be implemented by subclasses
    public abstract double computeCommission();

    // Getter methods for accessing policy details
    public String getPolicyNumber() {
        return policyNumber;
    }

    public String getPolicyHolderName() {
        return policyHolderName;
    }

    public double getPremiumAmount() {
        return premiumAmount;
    }

    // Override toString() to return basic policy details
    @Override
    public String toString() {
        return "Policy Number: " + policyNumber +
               "\nPolicy Holder: " + policyHolderName;
    }
}
