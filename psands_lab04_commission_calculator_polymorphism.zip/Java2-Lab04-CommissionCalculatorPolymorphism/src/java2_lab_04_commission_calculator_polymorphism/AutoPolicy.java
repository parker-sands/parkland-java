/******************************************************************************
*
* AutoPolicy.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Represents an Auto insurance policy.
* 2. Inherits common policy attributes from `Policy`.
* 3. Implements `computeCommission()` to calculate commission for auto policies.
* 4. Overrides `toString()` to provide a formatted output for policy details.
* 5. Demonstrates **polymorphism** by allowing `computeCommission()` and 
*    `toString()` to be called dynamically via a `Policy` reference.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Make `AutoPolicy` a subclass of `Policy` (`extends Policy`).
* 2. Implement a constructor to initialize values.
* 3. Override `computeCommission()` to return 30% of (liability + collision).
* 4. Ensure that `toString()` provides a formatted policy summary.
*
******************************************************************************
*
* LAB HINTS
* 1. Use `super()` in the constructor to call `Policy`'s constructor.
* 2. Compute commission as **30%** of (`liability + collision`).
* 3. Override `toString()` to include auto-specific details.
* 4. Ensure compatibility with `CommissionCalculator` for **dynamic method calls**.
*
******************************************************************************
*
* EXAMPLE PROGRAM OUTPUT (Generated from `CommissionCalculator`)
* Auto Policy
* -----------
* Policy Holder: Jerry
* Policy Number: A123
* Premium Amount: $1000.00
* Make: Toyota
* Model: Corolla
* Liability: $500.00
* Collision: $500.00
* Commission: $300.00
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Define `AutoPolicy` as a subclass (`extends Policy`) to inherit common policy attributes.
* 2. Implement a constructor that calls `super()` to initialize the policy number, 
*    policy holder name, and total coverage amount (liability + collision).
* 3. Override `computeCommission()` to return **30%** of (liability + collision).
* 4. Override `toString()` to display all policy details, including vehicle make, model, and commission.
* 5. Ensure that `computeCommission()` and `toString()` can be called dynamically when iterating 
*    through an `ArrayList<Policy>` in `CommissionCalculator`.
*
******************************************************************************
*
* INPUT
* 1. Policy details:
*    - Policy Number (String)
*    - Policy Holder Name (String)
*    - Make of Vehicle (String)
*    - Model of Vehicle (String)
*    - Liability Coverage (double)
*    - Collision Coverage (double)
*
* PROCESSING AND CALCULATIONS
* 1. Compute the total coverage: `liability + collision`.
* 2. Compute commission as **30%** of (`liability + collision`).
*
* OUTPUT
* 1. Displays policyholder details, vehicle information, and calculated commission.
*
*****************************************************************************/
package java2_lab_04_commission_calculator_polymorphism;

public class AutoPolicy extends Policy {
    private String make;
    private String model;
    private double liability;
    private double collision;

    public AutoPolicy(String policyNumber, String policyHolderName, String make, String model, double liability, double collision) {
        super(policyNumber, policyHolderName, liability + collision);  // Total premium amount
        this.make = make;
        this.model = model;
        this.liability = liability;
        this.collision = collision;
    }

    @Override
    public double computeCommission() {
        return (liability + collision) * 0.30;  // 30% commission
    }

    @Override
    public String toString() {
        return super.toString() +
               "\nMake: " + make +
               "\nModel: " + model +
               "\nLiability: $" + liability +
               "\nCollision: $" + collision +
               "\nCommission: $" + String.format("%.2f", computeCommission()) + "\n";
    }
}
