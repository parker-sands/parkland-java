/******************************************************************************
*
* GCDDriver.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Prompts the user for a numerator and denominator.
* 2. Instantiates a RationalNumber object with these values.
* 3. Calls the gcd() method and prints the result in formatted output.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Prompt the user for two positive integers.
* 2. Construct a RationalNumber using those values.
* 3. Compute and print the greatest common divisor using the recursive method.
*
******************************************************************************
*
* LAB HINTS
* 1. Use Scanner for input.
* 2. Validate inputs if necessary.
* 3. Print the result in the format:
*    "Greatest common denominator of [numerator]/[denominator] is [gcd]"
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Use Scanner to read user input for numerator and denominator.
* 2. Construct a RationalNumber object using these values.
* 3. Call rational.gcd() and store the result.
* 4. Print the formatted output to the console.
*
******************************************************************************
*
* INPUT
* 1. Two positive integers (numerator, denominator)
*
* PROCESSING AND CALCULATIONS
* 1. Use RationalNumber class to compute the GCD recursively
*
* OUTPUT
* 1. Printed message showing the simplified form of the rational number
*    with its greatest common denominator.
*
******************************************************************************
*
* PSEUDOCODE - GCDDriver Class
*
* CLASS GCDDriver
*
* MAIN METHOD:
*   CREATE Scanner object
*   PROMPT user for numerator
*   READ numerator from user
*   PROMPT user for denominator
*   READ denominator from user
*   CREATE RationalNumber object with numerator and denominator
*   CALL rational.gcd() and store result
*   PRINT "Greatest common denominator of [numerator]/[denominator] is [gcd]"
*
******************************************************************************/


package java2_lab_08_gcd_recursion;

import java.util.Scanner;

public class GCDDriver {

    // ANSI escape color codes
    public static final String RESET = "\u001B[0m";
    public static final String RED = "\u001B[31m";
    public static final String GREEN = "\u001B[32m";
    public static final String YELLOW = "\u001B[33m";
    public static final String CYAN = "\u001B[36m";
    public static final String MAGENTA = "\u001B[35m";
    public static final String BOLD = "\u001B[1m";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Opening banner
        System.out.println(MAGENTA + BOLD +
            "╔════════════════════════════════════════════════════╗\n" +
            "║          ✨ Welcome to the GCD Lounge ✨           ║\n" +
            "║        Where Numbers Meet Their Better Half        ║\n" +
            "╚════════════════════════════════════════════════════╝\n" + RESET);

        // Program loop
        while (true) {
            // Input: NUMERATOR
            System.out.print("Enter a " + GREEN + "POSITIVE" + RESET + " integer for the " +
                    YELLOW + "NUMERATOR" + RESET + " (don’t be shy): ");
            int numerator = scanner.nextInt();

            if (numerator == 69) {
                System.out.println("Nice.");
            }

            // Input: DENOMINATOR
            System.out.print("And now, a " + GREEN + "POSITIVEly" + RESET + " dashing " +
                    CYAN + "DENOMINATOR" + RESET + " to pair with that: ");
            int denominator = scanner.nextInt();

            if (numerator == 69 && denominator == 69) {
                typewriter("Twice-r is nicer.", 80);
            }

            // GCD Calculation
            RationalNumber rational = new RationalNumber(numerator, denominator);
            int gcd = rational.gcd();

            // Output Section
            System.out.println();
            System.out.println("Presenting Your Fraction, Refined and Radiant...");
            System.out.println("👉 Greatest common denominator of " +
                    YELLOW + rational.getNumerator() + RESET + "/" +
                    CYAN + rational.getDenominator() + RESET + " is " +
                    BOLD + GREEN + gcd + RESET);

            // GCD-based Commentary
            if (gcd == 69) {
                System.out.println("\n🌀 Some days the universe gives, some days the universe receives.🌀");
                System.out.println("#EveryYinHasItsYang");
            } else if (gcd % 2 == 0) {
                System.out.println("\n✨ Because even numbers deserve a glow-up. ✨");
            } else {
                System.out.println("\n😐 Because odd numbers are ingloriously common.");
            }

            System.out.println(); // Spacer

            // Continue or Quit
            System.out.println("-------------------------------------");
            System.out.println("Would you like to continue?");
            System.out.println("  [1] Yes, let's go again");
            System.out.println("  [2] No, I'm numerically fulfilled");
            System.out.println("-------------------------------------");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            System.out.println();

            if (choice == 69) {
                System.out.println("Don't be ridiculous! This is neither the time or the place.");
                System.out.println("Nice try.");
                System.out.println();
                continue;
            } else if (choice != 1) {
                System.out.println("🛑 Exiting the GCD Lounge... Your numbers have never looked better.");
                break;
            }

            if (choice != 1) {
                System.out.println("🛑 Exiting the GCD Lounge... Your numbers have never looked better.");
                break;
            }
        }

        scanner.close();
    }

    // Helper method: Typewriter effect for slow-reveal lines
    public static void typewriter(String message, int delayMillis) {
        for (char c : message.toCharArray()) {
            System.out.print(c);
            try {
                Thread.sleep(delayMillis);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        System.out.println();
    }
}


