/******************************************************************************
*
* RationalNumber.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Models a rational number using a numerator and denominator.
* 2. Provides a recursive method to calculate the greatest common divisor (GCD)
*    of the numerator and denominator using Euclid's Algorithm.
* 3. Enables simplification or analysis of fractions through internal logic.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Create a RationalNumber class with two integer fields:
*    - numerator
*    - denominator
* 2. Implement a public method gcd() that uses recursion to return the
*    greatest common divisor of the two values.
* 3. Utilize a private helper method for the recursive implementation.
*
******************************************************************************
*
* LAB HINTS
* 1. Use Math.abs() to avoid negative values impacting GCD calculation.
* 2. Base Case: If b == 0, return a.
* 3. Recursive Case: Return gcd(b, a % b).
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Store numerator and denominator as instance fields.
* 2. In the constructor, assign provided values to fields.
* 3. Create a public method gcd() that:
*    - Calls a private helper method, passing absolute values of fields.
* 4. Private helper method uses recursion per Euclid’s algorithm.
*
******************************************************************************
*
* INPUT
* 1. Numerator and denominator (positive integers)
*
* PROCESSING AND CALCULATIONS
* 1. Apply Euclid's recursive algorithm: gcd(a, b) = gcd(b, a % b)
*
* OUTPUT
* 1. Returns the greatest common divisor as an integer.
*
******************************************************************************
*
* PSEUDOCODE - RationalNumber Class
*
* CLASS RationalNumber
*
* VARIABLES:
*   numerator : int
*   denominator : int
*
* CONSTRUCTOR: RationalNumber(numerator: int, denominator: int)
*   SET this.numerator = numerator
*   SET this.denominator = denominator
*
* METHOD: gcd() -> int
*   RETURN gcd(Math.abs(numerator), Math.abs(denominator))
*
* METHOD: gcd(a: int, b: int) -> int
*   IF b == 0 THEN:
*       RETURN a
*   ELSE:
*       RETURN gcd(b, a % b)
*
******************************************************************************/


package java2_lab_08_gcd_recursion;

public class RationalNumber {
    // Instance variables for numerator and denominator
    private int numerator;
    private int denominator;

    /**
     * Constructor - initializes numerator and denominator
     * @param numerator the top value of the fraction
     * @param denominator the bottom value of the fraction
     */
    public RationalNumber(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
    }

    /**
     * Public method to return the GCD of the numerator and denominator.
     * Calls the recursive private helper method.
     * @return the greatest common divisor
     */
    public int gcd() {
        return gcd(Math.abs(numerator), Math.abs(denominator));
    }

    /**
     * Private recursive method that implements Euclid’s algorithm.
     * @param a first value
     * @param b second value
     * @return greatest common divisor of a and b
     */
    private int gcd(int a, int b) {
        if (b == 0) {
            return a;
        } else {
            return gcd(b, a % b);
        }
    }

    /**
     * Getter for numerator
     * @return numerator
     */
    public int getNumerator() {
        return numerator;
    }

    /**
     * Getter for denominator
     * @return denominator
     */
    public int getDenominator() {
        return denominator;
    }
}

