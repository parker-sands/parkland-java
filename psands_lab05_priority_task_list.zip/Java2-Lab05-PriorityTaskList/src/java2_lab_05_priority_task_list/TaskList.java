/******************************************************************************
*
* TaskList.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Driver class to demonstrate creating and displaying Task objects.
* 2. Initializes multiple `Task` instances with varying priorities.
* 3. Prints formatted task list to console.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Create a `main` method.
* 2. Instantiate several `Task` objects.
* 3. Set a unique priority (1–5) for each task.
* 4. Print tasks to console with clear formatting.
*
******************************************************************************
*
* LAB HINTS
* 1. Use an array or ArrayList to store tasks.
* 2. Print a heading and use consistent spacing for output.
* 3. Call `toString()` implicitly or explicitly when printing.
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Create a few tasks like "Attend class", "Exercise", etc.
* 2. Assign priorities (1 = highest, 5 = lowest).
* 3. Print each task using the `toString()` method.
*
******************************************************************************
*
* INPUT
* None – all task data is hardcoded for demo purposes.
*
* PROCESSING AND CALCULATIONS
* None.
*
* OUTPUT
* A formatted task list showing priorities from 1 to 5.
*
******************************************************************************/
package java2_lab_05_priority_task_list;

public class TaskList {
	public static String getTaskLine(Task t) {
	    String icon = switch (t.getPriority()) {
	        case 1 -> "🏫📚";      // Attend Class
	        case 2 -> "✏️💻";      // Homework
	        case 3 -> "💪🏃";      // Exercise
	        case 4 -> "☕🍳";      // Breakfast
	        case 5 -> "🥪🥗";      // Lunch
	        default -> "•";
	    };
	    return icon + "  " + t.toString();
	}
	public static void main(String[] args) {
	    Task t1 = new Task("Attend Class", 1);
	    Task t2 = new Task("Homework", 2);
	    Task t3 = new Task("Exercise", 3);
	    Task t4 = new Task("Eat Breakfast", 4);
	    Task t5 = new Task("Eat Lunch", 5);

	    System.out.println("╔════════════════════════════╗");
	    System.out.println("║     PRIORITY TASK LIST     ║");
	    System.out.println("╚════════════════════════════╝");
	    System.out.println();

	    System.out.println("📝 Tasks:");
	    System.out.println("════════════════════════════════════════");

	    System.out.println(getTaskLine(t1));
	    System.out.println(getTaskLine(t2));
	    System.out.println(getTaskLine(t3));
	    System.out.println(getTaskLine(t4));
	    System.out.println(getTaskLine(t5));
	}
}

