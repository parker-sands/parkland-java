/******************************************************************************
*
* Task.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Represents a single task with a description and priority level.
* 2. Implements `PriorityInterface` to allow setting and getting priority.
* 3. Encapsulates task-related data and behaviors.
* 4. Overrides `toString()` to format task details for display.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Create a `Task` class that implements `PriorityInterface`.
* 2. Include:
*    - A String to store the task description.
*    - An int to store priority (1–5).
* 3. Provide:
*    - A constructor to initialize description and priority.
*    - `setPriority(int)` and `getPriority()` methods.
*    - `toString()` method for formatted output.
*
******************************************************************************
*
* LAB HINTS
* 1. Use `implements PriorityInterface` in the class header.
* 2. In `setPriority()`, consider validating input (1–5).
* 3. Use `toString()` to return "description priority: x" format.
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Store task data: a string and a priority int.
* 2. Implement required interface methods.
* 3. Use a constructor to initialize data.
* 4. Format the display neatly to align in output.
*
******************************************************************************
*
* INPUT
* 1. Task description (String)
* 2. Priority level (int, 1–5)
*
* PROCESSING AND CALCULATIONS
* 1. None needed beyond storing and retrieving values.
*
* OUTPUT
* 1. A formatted string showing task description and priority.
*
******************************************************************************/
package java2_lab_05_priority_task_list;

public class Task implements PriorityInterface {
	private String description;
	private int priority;

	public Task(String desc, int level) {
		description = desc;
		priority = level;
	}
		
	public int getPriority() {
		return priority;
	}
		
	public void setPriority(int level) {
		priority = level;
	}
	
	@Override
	public String toString() {
	    String color;

	    switch (priority) {
	    case 1 -> color = "\u001B[31m";        // Red
	    case 2 -> color = "\u001B[38;5;208m";  // Orange
	    case 3 -> color = "\u001B[33m";        // Yellow
	    case 4 -> color = "\u001B[32m";        // Green
	    case 5 -> color = "\u001B[36m";        // Cyan (or try 94 or 96)
	    default -> color = "\u001B[0m";        // Reset
	}

	    return color + String.format("%-20s Priority: %d", description, priority) 
	    + "\u001B[0m";
	}
}
