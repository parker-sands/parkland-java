/******************************************************************************
*
* PriorityInterface.java
*
* Created by: Parker Sands
* Parkland College
* CSC-240, JAVA 2
* Spring 2025
*
******************************************************************************
*
* DESCRIPTION
* 1. Defines an interface for setting and getting task priority.
* 2. Intended for classes that need to assign priority levels (1–5).
* 3. Demonstrates abstraction by leaving implementation details to subclasses.
*
******************************************************************************
*
* LAB INSTRUCTIONS
* 1. Define a Java interface named `PriorityInterface`.
* 2. Include two method headers:
*    - `void setPriority(int level)`
*    - `int getPriority()`
* 3. Ensure no method bodies are included.
*
******************************************************************************
*
* LAB HINTS
* 1. No need to label methods as `abstract`—interface methods are abstract by default.
* 2. Keep method headers public by default in interfaces.
* 3. Avoid creating objects of type `PriorityInterface`.
*
******************************************************************************
*
* MY THOUGHT PROCESS
* 1. Create a basic interface with no data or constructors.
* 2. Focus only on defining what functionality any implementing class should provide.
* 3. Save implementation for the `Task` class.
*
******************************************************************************
*
* INPUT
* None. Interface only defines behavior.
*
* PROCESSING AND CALCULATIONS
* None. Implementing classes handle logic.
*
* OUTPUT
* None directly—output handled by implementing classes.
*
******************************************************************************/
package java2_lab_05_priority_task_list;

public interface PriorityInterface {
	void setPriority(int level);
	int getPriority();

}
